<?php ?>
.elgg-icon-digest-info {
	background: url("<?php echo elgg_get_site_url(); ?>_graphics/elgg_sprites.png") repeat scroll 0 -486px transparent;
    cursor: pointer;
    vertical-align: top;
}

.elgg-icon-digest-info:hover {
	background-position: 0 -468px;
}