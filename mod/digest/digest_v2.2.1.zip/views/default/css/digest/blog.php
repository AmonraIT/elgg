<?php
	/**
	* Blog CSS for the Digest message
	*/
?>

.digest-blog {
	padding: 10px 0px;
	display: inline-block;
	width: 100%;
}

.digest-blog img {
	float: left;
	padding: 5px 15px 0 0;
}

.digest-blog h4 {
	padding-bottom: 5px;
}

.digest-blog h4 a{
	text-decoration: none;
}