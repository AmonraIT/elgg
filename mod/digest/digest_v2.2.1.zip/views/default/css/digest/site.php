<?php 

?>
/* Digest CSS */
.digest-settings-title-info {
	vertical-align: top;
}

/* End digest CSS */