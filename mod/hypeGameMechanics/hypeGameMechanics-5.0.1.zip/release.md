![Elgg 3.0](https://img.shields.io/badge/Elgg-3.0-orange.svg?style=flat-square)

Self-contained .zip file that includes all plugin dependencies.
