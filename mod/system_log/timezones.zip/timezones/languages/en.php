<?php

return array(
	'timezones:user:set:timezone' => 'Your Time Zone',
	'timezones:user:current_time' => 'Your current time:',
	'timezones:user:timezone:label' => 'Give your Time Zone',

	'timezones:settings:timezone' => 'Time Zone',
	'timezones:settings:default_user_timezone' => 'Default user timezone:',
	'timezones:gmt_time' => 'GMT according to system timezone setting',
	);
?>
