<?php

return array(
	'timezones:user:set:timezone' => 'Uw tijdzone',
	'timezones:user:current_time' => 'Uw huidige tijd:',
	'timezones:user:timezone:label' => 'Geef uw tijdzone',

	'timezones:settings:timezone' => 'Tijdzone',
	'timezones:settings:default_user_timezone' => 'Standaard tijdzone gebruikers:',
	'timezones:gmt_time' => 'GMT volgens de systeem tijdzone instelling',
	);
?>
